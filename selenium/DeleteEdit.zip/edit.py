from selenium import webdriver
from selenium.webdriver.common.keys import Keys

driver = webdriver.Chrome()
driver.get("http://178.128.60.232/readit-3/")
login = driver.find_element_by_id("login")
login.click()
emailElement = driver.find_element_by_name("email")
emailElement.clear()
emailElement.send_keys("201601012@iacademy.edu.ph")
passwordElement = driver.find_element_by_name("password")
passwordElement.clear()
passwordElement.send_keys("domogoyoulikingsports")
loginBtnElement = driver.find_element_by_name("loginBtn")
loginBtnElement.click()

viewPost = driver.find_element_by_id("view")
viewPost.click()
driver.save_screenshot("viewpost.png")
edit = driver.find_element_by_name("editBtn")
edit.click()
driver.save_screenshot("editinfo.png")
titlePost = driver.find_element_by_name("post_title")
titlePost.clear()
titlePost.send_keys("edit title")
description = driver.find_element_by_name("post_description")
description.clear()
description.send_keys("edit description")

updatePost = driver.find_element_by_name("editPost")
updatePost.click()
driver.save_screenshot("doneupdating.png")





